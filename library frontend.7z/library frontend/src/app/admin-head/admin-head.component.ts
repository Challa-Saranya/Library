import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-head',
  templateUrl: './admin-head.component.html',
  styleUrls: ['./admin-head.component.css']
})
export class AdminHeadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
